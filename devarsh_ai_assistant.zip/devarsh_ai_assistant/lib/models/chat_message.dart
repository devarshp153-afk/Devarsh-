// models/chat_message.dart
import 'package:uuid/uuid.dart';

enum MessageSender { user, assistant }

class ChatMessage {
  final String id;
  final String text;
  final MessageSender sender;
  final DateTime timestamp;
  final bool isLoading;

  ChatMessage({
    String? id,
    required this.text,
    required this.sender,
    DateTime? timestamp,
    this.isLoading = false,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  bool get isAssistant => sender == MessageSender.assistant;
  bool get isUser => sender == MessageSender.user;

  ChatMessage copyWith({String? text, bool? isLoading}) => ChatMessage(
        id: id, text: text ?? this.text, sender: sender,
        timestamp: timestamp, isLoading: isLoading ?? this.isLoading);

  Map<String, dynamic> toJson() => {
        'id': id, 'text': text, 'sender': sender.name,
        'timestamp': timestamp.toIso8601String()};

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id'] as String,
        text: json['text'] as String,
        sender: MessageSender.values.byName(json['sender'] as String),
        timestamp: DateTime.parse(json['timestamp'] as String));
}
