// screens/home_screen.dart — Main assistant chat UI
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/assistant_provider.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/mic_button.dart';
import '../widgets/status_bar.dart';
import '../widgets/app_logo.dart';
import '../utils/theme.dart';
import 'settings_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _scrollCtrl = ScrollController();
  final _textCtrl   = TextEditingController();
  bool _showTextField = false;

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final state    = ref.watch(assistantProvider);
    final notifier = ref.read(assistantProvider.notifier);

    // Auto-scroll when messages update
    ref.listen(assistantProvider, (_, next) {
      if (next.messages.length != state.messages.length) _scrollToBottom();
    });

    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: AppLogo(size: 36),
        ),
        title: const Text('Devarsh AI'),
        actions: [
          // Service toggle button
          IconButton(
            tooltip: state.serviceRunning ? 'Stop background service' : 'Start background service',
            icon: Icon(
              state.serviceRunning ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
              color: state.serviceRunning ? AppTheme.accentColor : Colors.white38,
            ),
            onPressed: notifier.toggleService,
          ),
          // Clear chat
          IconButton(
            tooltip: 'Clear history',
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => _confirmClear(context, notifier),
          ),
          // Settings
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),

      body: Column(
        children: [
          // ── Chat messages ──────────────────────────────────────────────
          Expanded(
            child: state.messages.isEmpty
                ? _EmptyState()
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.only(top: 8, bottom: 8),
                    itemCount: state.messages.length,
                    itemBuilder: (_, i) =>
                        ChatBubble(message: state.messages[i]),
                  ),
          ),

          // ── Status bar ─────────────────────────────────────────────────
          AssistantStatusBar(
            speechState: state.speechState,
            isThinking: state.isThinking,
            partialText: state.partialText,
          ),

          // ── Text input (optional) ──────────────────────────────────────
          if (_showTextField)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _textCtrl,
                      autofocus: true,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                          hintText: 'Type a command...'),
                      onSubmitted: (t) {
                        notifier.sendTextMessage(t);
                        _textCtrl.clear();
                        setState(() => _showTextField = false);
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.send_rounded, color: AppTheme.primaryColor),
                    onPressed: () {
                      notifier.sendTextMessage(_textCtrl.text);
                      _textCtrl.clear();
                      setState(() => _showTextField = false);
                    },
                  ),
                ],
              ),
            ),

          // ── Bottom bar: mic + keyboard toggle ─────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Keyboard toggle
                IconButton(
                  icon: Icon(
                    _showTextField ? Icons.keyboard_hide_rounded : Icons.keyboard_rounded,
                    color: Colors.white38,
                  ),
                  onPressed: () => setState(() => _showTextField = !_showTextField),
                ),

                // Main mic button
                MicButton(
                  speechState: state.speechState,
                  onTap: notifier.startListening,
                ),

                // Stop TTS
                IconButton(
                  icon: const Icon(Icons.volume_off_rounded, color: Colors.white38),
                  onPressed: notifier.stopSpeaking,
                  tooltip: 'Stop speaking',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _confirmClear(BuildContext ctx, AssistantNotifier notifier) {
    showDialog(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text('Delete all chat messages?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          TextButton(
            onPressed: () { Navigator.pop(c); notifier.clearHistory(); },
            child: const Text('Clear', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppLogo(size: 80),
          const SizedBox(height: 24),
          Text('Devarsh AI Assistant',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('Tap the mic and speak a command',
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 24),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: [
              '"Open YouTube"', '"Turn on flashlight"',
              '"Set alarm for 7 AM"', '"What is AI?"',
            ].map((t) => Chip(
              label: Text(t,
                  style: const TextStyle(fontSize: 12, color: Colors.white70)),
              backgroundColor: AppTheme.cardColor,
              side: BorderSide(color: Colors.white.withOpacity(0.1)),
            )).toList(),
          ),
        ],
      ),
    );
  }
}
