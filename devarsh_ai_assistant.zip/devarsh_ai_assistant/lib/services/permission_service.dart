// services/permission_service.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

class PermissionService {
  PermissionService._();

  /// Request critical runtime permissions. Returns true if mic + notification granted.
  static Future<bool> requestAllPermissions(BuildContext context) async {
    final statuses = await [
      Permission.microphone,
      Permission.notification,
      Permission.camera,
    ].request();
    final micOk   = statuses[Permission.microphone]?.isGranted ?? false;
    final notifOk = statuses[Permission.notification]?.isGranted ?? false;
    if (!micOk && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Microphone permission required for voice commands.'),
        action: SnackBarAction(label: 'Settings', onPressed: openAppSettings),
        duration: const Duration(seconds: 5),
      ));
    }
    return micOk && notifOk;
  }

  static Future<bool> hasMicrophonePermission() =>
      Permission.microphone.isGranted;

  /// Guide user to disable battery optimisation for background service.
  /// Android does NOT allow apps to do this programmatically.
  static Future<void> requestBatteryOptimizationExemption(BuildContext ctx) async {
    if (!Platform.isAndroid) return;
    if (await FlutterForegroundTask.isIgnoringBatteryOptimizations) return;
    if (!ctx.mounted) return;
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('Battery Optimisation'),
        content: const Text(
          'To keep the assistant running in the background, tap Allow on the '
          'next screen and select "Don\'t optimise" for this app.\n\n'
          'Without this, Android may kill the assistant when the screen is off.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Skip')),
          TextButton(onPressed: () => Navigator.pop(c, true),  child: const Text('Allow')),
        ],
      ),
    );
    if (ok == true) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
  }
}
