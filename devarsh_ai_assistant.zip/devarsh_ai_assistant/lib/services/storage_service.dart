// services/storage_service.dart — SharedPreferences abstraction
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_settings.dart';
import '../models/chat_message.dart';
import '../utils/constants.dart';

class StorageService {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Settings
  static Future<void> saveSettings(AppSettings s) async {
    await _prefs?.setString('settings', jsonEncode(s.toJson()));
  }

  static AppSettings loadSettings() {
    final raw = _prefs?.getString('settings');
    if (raw == null) return const AppSettings();
    try { return AppSettings.fromJson(jsonDecode(raw)); }
    catch (_) { return const AppSettings(); }
  }

  // Chat history (last 50 messages)
  static Future<void> saveChatHistory(List<ChatMessage> msgs) async {
    final limited = msgs.take(50).toList();
    await _prefs?.setString(
        AppConstants.keyChatHistory,
        jsonEncode(limited.map((m) => m.toJson()).toList()));
  }

  static List<ChatMessage> loadChatHistory() {
    final raw = _prefs?.getString(AppConstants.keyChatHistory);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list.map((e) => ChatMessage.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) { return []; }
  }

  static Future<void> clearChatHistory() async =>
      _prefs?.remove(AppConstants.keyChatHistory);

  static bool get onboardingDone =>
      _prefs?.getBool(AppConstants.keyOnboardingDone) ?? false;

  static Future<void> setOnboardingDone() =>
      _prefs?.setBool(AppConstants.keyOnboardingDone, true) ?? Future.value();
}
