// screens/onboarding_screen.dart — first-run setup
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/permission_service.dart';
import '../services/storage_service.dart';
import '../widgets/app_logo.dart';
import '../utils/theme.dart';
import 'home_screen.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  bool _loading = false;

  Future<void> _grantAndContinue() async {
    setState(() => _loading = true);
    await PermissionService.requestAllPermissions(context);
    if (context.mounted) {
      await PermissionService.requestBatteryOptimizationExemption(context);
    }
    await StorageService.setOnboardingDone();
    if (context.mounted) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const Spacer(),
              AppLogo(size: 100),
              const SizedBox(height: 32),
              Text('Devarsh AI Assistant',
                  style: Theme.of(context).textTheme.displayLarge,
                  textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text(
                'Your personal JARVIS-style AI assistant.\nSpeak commands to open apps, control your device, and chat with AI.',
                style: Theme.of(context).textTheme.bodyLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              ...[
                _FeatureTile(Icons.mic_rounded, 'Voice Commands',
                    'Say "Open YouTube", "Turn on flashlight" and more'),
                _FeatureTile(Icons.psychology_rounded, 'AI Powered',
                    'Powered by Google Gemini or OpenAI GPT'),
                _FeatureTile(Icons.notifications_active_rounded, 'Background Service',
                    'Persistent notification keeps assistant alive'),
              ],
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _grantAndContinue,
                  child: _loading
                      ? const SizedBox(height: 20, width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Get Started'),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _FeatureTile(this.icon, this.title, this.subtitle);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Row(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppTheme.accentColor, size: 22),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                Text(subtitle, style: const TextStyle(
                    color: Colors.white54, fontSize: 12)),
              ],
            )),
          ],
        ),
      );
}
