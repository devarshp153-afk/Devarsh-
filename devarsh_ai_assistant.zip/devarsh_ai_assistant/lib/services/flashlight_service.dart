// services/flashlight_service.dart — wraps torch_light package
import 'package:torch_light/torch_light.dart';

class FlashlightService {
  FlashlightService._();
  static bool _isOn = false;
  static bool get isOn => _isOn;

  static Future<bool> turnOn() async {
    try {
      await TorchLight.enableTorch();
      _isOn = true;
      return true;
    } catch (_) { return false; }
  }

  static Future<bool> turnOff() async {
    try {
      await TorchLight.disableTorch();
      _isOn = false;
      return true;
    } catch (_) { return false; }
  }

  static Future<bool> toggle() async => _isOn ? turnOff() : turnOn();

  static Future<bool> isAvailable() async {
    try {
      return await TorchLight.isTorchAvailable();
    } catch (_) { return false; }
  }
}
