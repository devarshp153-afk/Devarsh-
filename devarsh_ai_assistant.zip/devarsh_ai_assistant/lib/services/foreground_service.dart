// services/foreground_service.dart
// Manages the Android Foreground Service via flutter_foreground_task.
// The foreground service shows a persistent notification and keeps the
// Dart isolate alive when the app is minimized.
//
// ANDROID RESTRICTIONS (cannot be bypassed):
//   - If the user "Force Stop" the app in Android Settings, the service
//     will be killed and CANNOT auto-restart. The user must reopen the app.
//   - The service cannot access UI or show dialogs while in background.
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import '../utils/constants.dart';

// Top-level callback required by flutter_foreground_task
// This runs in a SEPARATE Dart isolate — no Flutter UI access here.
@pragma('vm:entry-point')
void startForegroundServiceCallback() {
  FlutterForegroundTask.setTaskHandler(_AssistantTaskHandler());
}

class _AssistantTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    // Service started — we can send data to the main isolate via sendPort
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    // Called at the repeat interval. Used to keep the isolate alive.
    // Heavy processing (STT, API calls) happens in the main isolate.
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    // Service stopping — clean up resources here
  }
}

class ForegroundServiceManager {
  ForegroundServiceManager._();

  static void initOptions() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: AppConstants.notifChannelId,
        channelName: AppConstants.notifChannelName,
        channelDescription: 'Keeps Devarsh AI Assistant running in the background',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
        iconData: const NotificationIconData(
          resType: ResourceType.mipmap,
          resPrefix: ResourcePrefix.ic,
          name: 'launcher',
        ),
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: const ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: true,     // restart after device reboot
        autoRunOnMyPackageReplaced: true,
        allowWakeLock: true,     // prevent CPU sleep
        allowWifiLock: false,
      ),
    );
  }

  static Future<void> start() async {
    if (await FlutterForegroundTask.isRunningService) return;
    await FlutterForegroundTask.startService(
      notificationTitle: AppConstants.serviceTitle,
      notificationText: AppConstants.serviceBody,
      callback: startForegroundServiceCallback,
    );
  }

  static Future<void> stop() async {
    if (!await FlutterForegroundTask.isRunningService) return;
    await FlutterForegroundTask.stopService();
  }

  static Future<bool> get isRunning =>
      FlutterForegroundTask.isRunningService;

  static Future<void> updateNotification(String text) async {
    await FlutterForegroundTask.updateService(
      notificationTitle: AppConstants.serviceTitle,
      notificationText: text,
    );
  }
}
