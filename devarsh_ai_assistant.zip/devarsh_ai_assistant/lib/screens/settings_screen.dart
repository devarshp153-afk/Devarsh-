// screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/assistant_provider.dart';
import '../models/app_settings.dart';
import '../utils/theme.dart';
import '../services/permission_service.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});
  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late TextEditingController _apiKeyCtrl;
  bool _obscureKey = true;

  @override
  void initState() {
    super.initState();
    _apiKeyCtrl = TextEditingController(
        text: ref.read(settingsProvider).apiKey);
  }

  @override
  void dispose() { _apiKeyCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          _SectionHeader('AI Provider'),
          _Card(child: Column(children: [
            RadioListTile<AiProvider>(
              title: const Text('Google Gemini (Free tier available)'),
              subtitle: const Text('Recommended for beginners'),
              value: AiProvider.gemini,
              groupValue: settings.aiProvider,
              onChanged: (v) => notifier.update(settings.copyWith(aiProvider: v)),
            ),
            RadioListTile<AiProvider>(
              title: const Text('OpenAI GPT-4o Mini'),
              subtitle: const Text('Requires paid API key'),
              value: AiProvider.openai,
              groupValue: settings.aiProvider,
              onChanged: (v) => notifier.update(settings.copyWith(aiProvider: v)),
            ),
          ])),

          const SizedBox(height: 16),
          _SectionHeader('API Key'),
          _Card(child: TextField(
            controller: _apiKeyCtrl,
            obscureText: _obscureKey,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: settings.aiProvider == AiProvider.gemini
                  ? 'AIza...'
                  : 'sk-...',
              label: Text(settings.aiProvider == AiProvider.gemini
                  ? 'Gemini API Key' : 'OpenAI API Key'),
              suffixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(_obscureKey ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                    onPressed: () => setState(() => _obscureKey = !_obscureKey),
                  ),
                  IconButton(
                    icon: const Icon(Icons.save_outlined, color: AppTheme.accentColor),
                    onPressed: () {
                      notifier.update(settings.copyWith(apiKey: _apiKeyCtrl.text.trim()));
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('API key saved!')));
                    },
                  ),
                ],
              ),
            ),
          )),

          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              settings.aiProvider == AiProvider.gemini
                  ? 'Get free key at: aistudio.google.com/app/apikey'
                  : 'Get key at: platform.openai.com/api-keys',
              style: const TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ),

          const SizedBox(height: 16),
          _SectionHeader('Voice Settings'),
          _Card(child: Column(children: [
            ListTile(
              title: const Text('Speech Speed'),
              subtitle: Slider(
                value: settings.ttsSpeed,
                min: 0.1, max: 1.0, divisions: 9,
                label: '${(settings.ttsSpeed * 100).round()}%',
                onChanged: (v) => notifier.update(settings.copyWith(ttsSpeed: v)),
              ),
            ),
          ])),

          const SizedBox(height: 16),
          _SectionHeader('Background Service'),
          _Card(child: SwitchListTile(
            title: const Text('Auto-start on boot'),
            subtitle: const Text('Restart assistant after device reboot'),
            value: settings.autoStartOnBoot,
            onChanged: (v) => notifier.update(settings.copyWith(autoStartOnBoot: v)),
          )),

          const SizedBox(height: 8),
          _Card(child: ListTile(
            title: const Text('Battery Optimisation'),
            subtitle: const Text(
                'Disable to keep assistant alive in background'),
            trailing: ElevatedButton(
              child: const Text('Disable'),
              onPressed: () =>
                  PermissionService.requestBatteryOptimizationExemption(context),
            ),
          )),

          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(title,
          style: const TextStyle(
              color: AppTheme.accentColor,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2)));
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) =>
      Card(margin: EdgeInsets.zero, child: child);
}
