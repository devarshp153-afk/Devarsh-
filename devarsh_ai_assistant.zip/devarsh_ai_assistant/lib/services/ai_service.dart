// services/ai_service.dart
// Sends user messages to Gemini or OpenAI and returns text responses.
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/app_settings.dart';
import '../models/chat_message.dart';
import '../utils/constants.dart';

class AiService {
  AiService._();

  /// Send [messages] history to the configured AI provider.
  /// Returns the assistant reply text, or throws on error.
  static Future<String> sendMessage({
    required List<ChatMessage> messages,
    required AppSettings settings,
  }) async {
    if (settings.apiKey.isEmpty) {
      throw Exception(
          'No API key configured. Please add your API key in Settings.');
    }
    switch (settings.aiProvider) {
      case AiProvider.gemini:
        return _callGemini(messages: messages, apiKey: settings.apiKey);
      case AiProvider.openai:
        return _callOpenAi(messages: messages, apiKey: settings.apiKey);
    }
  }

  // ── Gemini ─────────────────────────────────────────────────────────────
  static Future<String> _callGemini({
    required List<ChatMessage> messages,
    required String apiKey,
  }) async {
    final url = Uri.parse(
        '\${AppConstants.geminiBaseUrl}/models/\${AppConstants.geminiModel}'
        ':generateContent?key=\$apiKey');

    // Build Gemini content array (user/model turns)
    final contents = <Map<String, dynamic>>[];

    // System instruction as the first user message (Gemini 1.5 approach)
    contents.add({
      'role': 'user',
      'parts': [{'text': AppConstants.systemPrompt}]
    });
    contents.add({
      'role': 'model',
      'parts': [{'text': 'Understood, Master Devarsh. I am ready to assist.'}]
    });

    for (final msg in messages) {
      contents.add({
        'role': msg.isUser ? 'user' : 'model',
        'parts': [{'text': msg.text}]
      });
    }

    final response = await http.post(url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': contents,
          'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 256},
        }));

    if (response.statusCode != 200) {
      throw Exception('Gemini API error \${response.statusCode}: \${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['candidates'][0]['content']['parts'][0]['text'] as String).trim();
  }

  // ── OpenAI ─────────────────────────────────────────────────────────────
  static Future<String> _callOpenAi({
    required List<ChatMessage> messages,
    required String apiKey,
  }) async {
    final url = Uri.parse('\${AppConstants.openAiBaseUrl}/chat/completions');

    final openAiMessages = <Map<String, dynamic>>[
      {'role': 'system', 'content': AppConstants.systemPrompt}
    ];
    for (final msg in messages) {
      openAiMessages.add({
        'role': msg.isUser ? 'user' : 'assistant',
        'content': msg.text,
      });
    }

    final response = await http.post(url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer \$apiKey',
        },
        body: jsonEncode({
          'model': AppConstants.openAiModel,
          'messages': openAiMessages,
          'max_tokens': 256,
          'temperature': 0.7,
        }));

    if (response.statusCode != 200) {
      throw Exception('OpenAI API error \${response.statusCode}: \${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['choices'][0]['message']['content'] as String).trim();
  }
}
