// services/assistant_provider.dart
// Riverpod state-notifier that coordinates all assistant features:
// speech -> command parsing -> AI / intent -> TTS.
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/chat_message.dart';
import '../models/app_settings.dart';
import '../utils/command_parser.dart';
import 'speech_service.dart';
import 'tts_service.dart';
import 'ai_service.dart';
import 'intent_service.dart';
import 'flashlight_service.dart';
import 'storage_service.dart';
import 'foreground_service.dart';

// ── Providers ────────────────────────────────────────────────────────────────
final settingsProvider = StateNotifierProvider<SettingsNotifier, AppSettings>(
    (ref) => SettingsNotifier());

final assistantProvider =
    StateNotifierProvider<AssistantNotifier, AssistantState>(
        (ref) => AssistantNotifier(ref));

// ── Settings notifier ────────────────────────────────────────────────────────
class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier() : super(StorageService.loadSettings());

  Future<void> update(AppSettings s) async {
    state = s;
    await StorageService.saveSettings(s);
  }
}

// ── Assistant state ──────────────────────────────────────────────────────────
class AssistantState {
  final List<ChatMessage> messages;
  final SpeechState speechState;
  final String partialText;
  final bool isThinking;
  final bool serviceRunning;
  final String? errorMessage;

  const AssistantState({
    this.messages = const [],
    this.speechState = SpeechState.idle,
    this.partialText = '',
    this.isThinking = false,
    this.serviceRunning = false,
    this.errorMessage,
  });

  AssistantState copyWith({
    List<ChatMessage>? messages, SpeechState? speechState,
    String? partialText, bool? isThinking,
    bool? serviceRunning, String? errorMessage,
  }) => AssistantState(
        messages: messages ?? this.messages,
        speechState: speechState ?? this.speechState,
        partialText: partialText ?? this.partialText,
        isThinking: isThinking ?? this.isThinking,
        serviceRunning: serviceRunning ?? this.serviceRunning,
        errorMessage: errorMessage,
      );
}

// ── Main notifier ────────────────────────────────────────────────────────────
class AssistantNotifier extends StateNotifier<AssistantState> {
  final Ref _ref;
  final SpeechService _speech = SpeechService();
  final TtsService _tts = TtsService();

  AssistantNotifier(this._ref) : super(const AssistantState()) {
    _init();
  }

  Future<void> _init() async {
    final settings = _ref.read(settingsProvider);
    await _tts.initialize(speed: settings.ttsSpeed, language: settings.ttsLanguage);
    final history = StorageService.loadChatHistory();
    final running = await ForegroundServiceManager.isRunning;
    state = state.copyWith(messages: history, serviceRunning: running);
    if (history.isEmpty) {
      _addAssistantMessage(
          'Hello, Master Devarsh! I am your AI assistant. '
          'Press the microphone button and speak a command.');
    }
  }

  // ── Listening ──────────────────────────────────────────────────────────────
  Future<void> startListening() async {
    if (state.speechState == SpeechState.listening) {
      await _speech.stopListening();
      return;
    }
    state = state.copyWith(speechState: SpeechState.listening, errorMessage: null);
    await _speech.startListening(
      onResult: _handleFinalSpeech,
      onPartialResult: (p) => state = state.copyWith(partialText: p),
      onError: (e) {
        state = state.copyWith(speechState: SpeechState.idle, errorMessage: e);
      },
      onStateChange: (s) => state = state.copyWith(speechState: s),
    );
  }

  Future<void> stopListening() => _speech.stopListening();

  // ── Command handling ────────────────────────────────────────────────────────
  Future<void> _handleFinalSpeech(String text) async {
    if (text.trim().isEmpty) return;
    state = state.copyWith(partialText: '');
    _addUserMessage(text);

    final cmd = CommandParser.parse(text);
    switch (cmd.type) {
      case CommandType.openApp:
        await _handleOpenApp(cmd.appName ?? text);
        break;
      case CommandType.flashlightOn:
        await _handleFlashlight(true);
        break;
      case CommandType.flashlightOff:
        await _handleFlashlight(false);
        break;
      case CommandType.openCamera:
        await IntentService.openCamera();
        _speak('Opening camera for you, Master Devarsh.');
        break;
      case CommandType.openSettings:
        await IntentService.openSettings();
        _speak('Opening device settings.');
        break;
      case CommandType.openDialer:
        await IntentService.openDialer(cmd.phoneNumber ?? '');
        _speak('Opening dialer.');
        break;
      case CommandType.openSms:
        await IntentService.openSms();
        _speak('Opening messages.');
        break;
      case CommandType.setAlarm:
        await _handleSetAlarm(cmd);
        break;
      case CommandType.aiQuery:
        await _sendToAi(text);
        break;
    }
  }

  Future<void> _handleOpenApp(String name) async {
    _speak('Opening $name.');
    _addAssistantMessage('Opening $name...');
    final ok = await IntentService.openAppByName(name);
    if (!ok) {
      final msg = 'I could not find an app named "$name" on your device.';
      _addAssistantMessage(msg);
      _speak(msg);
    }
  }

  Future<void> _handleFlashlight(bool on) async {
    final ok = on
        ? await FlashlightService.turnOn()
        : await FlashlightService.turnOff();
    final msg = ok
        ? 'Flashlight ${on ? "on" : "off"}, Master Devarsh.'
        : 'Unable to control flashlight. Is the camera in use?';
    _addAssistantMessage(msg);
    _speak(msg);
  }

  Future<void> _handleSetAlarm(CommandResult cmd) async {
    if (cmd.alarmHour != null) {
      await IntentService.setAlarm(
          hour: cmd.alarmHour!, minute: cmd.alarmMinute ?? 0);
      final msg =
          'Setting your alarm for ${cmd.alarmHour}:${(cmd.alarmMinute ?? 0).toString().padLeft(2, "0")}.';
      _addAssistantMessage(msg);
      _speak(msg);
    } else {
      const msg = 'Opening the alarm app so you can set the time manually.';
      _addAssistantMessage(msg);
      _speak(msg);
      await IntentService.openAppByName('clock');
    }
  }

  Future<void> _sendToAi(String text) async {
    state = state.copyWith(isThinking: true);
    final loadingId = _addAssistantMessage('...', isLoading: true);
    try {
      final settings = _ref.read(settingsProvider);
      final reply = await AiService.sendMessage(
          messages: state.messages.where((m) => !m.isLoading).toList(),
          settings: settings);
      _replaceMessage(loadingId, reply);
      _speak(reply);
    } catch (e) {
      final errMsg = 'Sorry, I could not reach the AI service. ${e.toString()}';
      _replaceMessage(loadingId, errMsg);
      _speak(errMsg);
    } finally {
      state = state.copyWith(isThinking: false);
    }
  }

  // ── Foreground Service ─────────────────────────────────────────────────────
  Future<void> toggleService() async {
    if (state.serviceRunning) {
      await ForegroundServiceManager.stop();
      state = state.copyWith(serviceRunning: false);
    } else {
      await ForegroundServiceManager.start();
      state = state.copyWith(serviceRunning: true);
    }
  }

  // ── Text input fallback ────────────────────────────────────────────────────
  Future<void> sendTextMessage(String text) async {
    if (text.trim().isEmpty) return;
    await _handleFinalSpeech(text);
  }

  // ── TTS ───────────────────────────────────────────────────────────────────
  Future<void> _speak(String text) => _tts.speak(text);
  Future<void> stopSpeaking()     => _tts.stop();

  Future<void> clearHistory() async {
    await StorageService.clearChatHistory();
    state = state.copyWith(messages: []);
    _addAssistantMessage('Chat history cleared. Ready for new commands, Master Devarsh!');
  }

  // ── Internal helpers ──────────────────────────────────────────────────────
  String _addAssistantMessage(String text, {bool isLoading = false}) {
    final msg = ChatMessage(
        text: text, sender: MessageSender.assistant, isLoading: isLoading);
    final updated = [...state.messages, msg];
    state = state.copyWith(messages: updated);
    StorageService.saveChatHistory(updated);
    return msg.id;
  }

  void _addUserMessage(String text) {
    final msg = ChatMessage(text: text, sender: MessageSender.user);
    final updated = [...state.messages, msg];
    state = state.copyWith(messages: updated);
    StorageService.saveChatHistory(updated);
  }

  void _replaceMessage(String id, String newText) {
    final updated = state.messages.map((m) =>
        m.id == id ? m.copyWith(text: newText, isLoading: false) : m).toList();
    state = state.copyWith(messages: updated, isThinking: false);
    StorageService.saveChatHistory(updated);
  }

  @override
  void dispose() {
    _speech.dispose();
    _tts.dispose();
    super.dispose();
  }
}
