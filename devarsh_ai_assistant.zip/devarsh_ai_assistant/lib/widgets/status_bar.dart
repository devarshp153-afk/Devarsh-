// widgets/status_bar.dart — shows listening / thinking status
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/theme.dart';
import '../services/speech_service.dart';

class AssistantStatusBar extends StatelessWidget {
  final SpeechState speechState;
  final bool isThinking;
  final String partialText;

  const AssistantStatusBar({
    super.key,
    required this.speechState,
    required this.isThinking,
    required this.partialText,
  });

  @override
  Widget build(BuildContext context) {
    String label;
    Color color;
    IconData icon;

    if (speechState == SpeechState.listening) {
      label = partialText.isNotEmpty ? partialText : 'Listening...';
      color = AppTheme.accentColor;
      icon = Icons.graphic_eq_rounded;
    } else if (isThinking) {
      label = 'Thinking...';
      color = AppTheme.primaryColor;
      icon = Icons.psychology_rounded;
    } else {
      label = 'Tap mic to speak';
      color = Colors.white30;
      icon = Icons.mic_none_rounded;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.inter(
                  color: color, fontSize: 13, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }
}
