// widgets/mic_button.dart — Animated microphone button
import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../services/speech_service.dart';

class MicButton extends StatefulWidget {
  final SpeechState speechState;
  final VoidCallback onTap;

  const MicButton({super.key, required this.speechState, required this.onTap});

  @override
  State<MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<MicButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _pulse = Tween<double>(begin: 1.0, end: 1.25).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void didUpdateWidget(MicButton old) {
    super.didUpdateWidget(old);
    if (widget.speechState == SpeechState.listening) {
      _ctrl.repeat(reverse: true);
    } else {
      _ctrl.stop();
      _ctrl.animateTo(0);
    }
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final isListening = widget.speechState == SpeechState.listening;
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, child) => Transform.scale(
        scale: isListening ? _pulse.value : 1.0,
        child: child,
      ),
      child: GestureDetector(
        onTap: widget.onTap,
        child: Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: isListening
                ? [AppTheme.accentColor, AppTheme.primaryColor]
                : [AppTheme.primaryColor, const Color(0xFF3A3DBF)]),
            boxShadow: [BoxShadow(
              color: (isListening ? AppTheme.accentColor : AppTheme.primaryColor)
                  .withOpacity(0.45),
              blurRadius: isListening ? 28 : 14,
              spreadRadius: isListening ? 4 : 0,
            )],
          ),
          child: Icon(
            isListening ? Icons.stop_rounded : Icons.mic_rounded,
            color: Colors.white,
            size: 36,
          ),
        ),
      ),
    );
  }
}
