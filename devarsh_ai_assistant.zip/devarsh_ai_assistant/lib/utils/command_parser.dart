// utils/command_parser.dart
// Parses raw speech into structured commands before hitting the AI.
import 'constants.dart';

enum CommandType {
  openApp, flashlightOn, flashlightOff,
  openDialer, openSms, setAlarm,
  openSettings, openCamera, aiQuery,
}

class CommandResult {
  final CommandType type;
  final String? appName;
  final String? phoneNumber;
  final int? alarmHour;
  final int? alarmMinute;
  final String rawText;

  const CommandResult({
    required this.type,
    required this.rawText,
    this.appName,
    this.phoneNumber,
    this.alarmHour,
    this.alarmMinute,
  });
}

class CommandParser {
  CommandParser._();

  static CommandResult parse(String text) {
    final lower = text.toLowerCase().trim();

    // Flashlight
    if (_has(lower, ['turn on flashlight','flashlight on','torch on','turn on torch']))
      return CommandResult(type: CommandType.flashlightOn, rawText: text);
    if (_has(lower, ['turn off flashlight','flashlight off','torch off','turn off torch']))
      return CommandResult(type: CommandType.flashlightOff, rawText: text);

    // Camera
    if (_contains(lower, ['open camera','take photo','take picture']))
      return CommandResult(type: CommandType.openCamera, rawText: text);

    // Settings
    if (_contains(lower, ['open settings','go to settings']))
      return CommandResult(type: CommandType.openSettings, rawText: text);

    // Dialer
    final callMatch = RegExp(r'(?:call|dial)\s+([\d\s\+\-]+)').firstMatch(lower);
    if (callMatch != null)
      return CommandResult(
          type: CommandType.openDialer, rawText: text,
          phoneNumber: callMatch.group(1)!.replaceAll(' ', ''));

    // SMS
    if (_contains(lower, ['send message','send sms','open messages','open sms']))
      return CommandResult(type: CommandType.openSms, rawText: text);

    // Alarm
    if (_contains(lower, ['set alarm','alarm for','alarm at','wake me']))
      return CommandResult(
          type: CommandType.setAlarm, rawText: text,
          alarmHour: _parseTime(lower)?[0],
          alarmMinute: _parseTime(lower)?[1]);

    // Open app (verb present)
    final openMatch = RegExp(r'(?:open|launch|start|run)\s+(.+)').firstMatch(lower);
    if (openMatch != null)
      return CommandResult(
          type: CommandType.openApp, rawText: text,
          appName: openMatch.group(1)!.trim());

    // Direct app name
    for (final app in AppConstants.knownAppNames) {
      if (lower == app || lower == 'go to $app')
        return CommandResult(type: CommandType.openApp, rawText: text, appName: app);
    }

    // Fallback → AI
    return CommandResult(type: CommandType.aiQuery, rawText: text);
  }

  static bool _has(String t, List<String> kws) => kws.any((k) => t == k);
  static bool _contains(String t, List<String> kws) => kws.any((k) => t.contains(k));

  static List<int>? _parseTime(String text) {
    final hhmm = RegExp(r'(\d{1,2}):(\d{2})\s*(am|pm)?').firstMatch(text);
    if (hhmm != null) {
      int h = int.parse(hhmm.group(1)!);
      final m = int.parse(hhmm.group(2)!);
      final ap = hhmm.group(3);
      if (ap == 'pm' && h < 12) h += 12;
      if (ap == 'am' && h == 12) h = 0;
      return [h, m];
    }
    final hAm = RegExp(r'(\d{1,2})\s*(am|pm)').firstMatch(text);
    if (hAm != null) {
      int h = int.parse(hAm.group(1)!);
      final ap = hAm.group(2)!;
      if (ap == 'pm' && h < 12) h += 12;
      if (ap == 'am' && h == 12) h = 0;
      return [h, 0];
    }
    return null;
  }
}
