// utils/constants.dart — app-wide constants
class AppConstants {
  AppConstants._();

  static const String appName = 'Devarsh AI Assistant';
  static const String appVersion = '1.0.0';

  // SharedPreferences keys
  static const String keyApiKey = 'api_key';
  static const String keyAiProvider = 'ai_provider';
  static const String keyTtsSpeed = 'tts_speed';
  static const String keyTtsLanguage = 'tts_language';
  static const String keyAutoStartOnBoot = 'auto_start_on_boot';
  static const String keyChatHistory = 'chat_history';
  static const String keyOnboardingDone = 'onboarding_done';

  // Gemini API — get free key at https://aistudio.google.com/app/apikey
  static const String geminiBaseUrl =
      'https://generativelanguage.googleapis.com/v1beta';
  static const String geminiModel = 'gemini-1.5-flash';

  // OpenAI API
  static const String openAiBaseUrl = 'https://api.openai.com/v1';
  static const String openAiModel = 'gpt-4o-mini';

  // Notification
  static const String notifChannelId = 'devarsh_assistant_channel';
  static const String notifChannelName = 'Devarsh Assistant';
  static const int notifId = 1001;

  // Foreground service
  static const String serviceTitle = 'Devarsh AI Assistant';
  static const String serviceBody = 'Assistant is running in background';

  // System prompt sent with every AI request
  static const String systemPrompt =
      'You are Devarsh AI Assistant, a helpful and concise JARVIS-style voice '
      'assistant running on an Android device. Keep replies short (2-3 sentences) '
      'and natural for voice output. When asked to open an app or perform a device '
      'action, confirm briefly. If an action is restricted by Android, explain why.';

  static const List<String> knownAppNames = [
    'youtube', 'whatsapp', 'camera', 'settings', 'chrome',
    'google', 'maps', 'gmail', 'instagram', 'facebook',
    'twitter', 'spotify', 'netflix', 'calculator', 'calendar',
    'clock', 'contacts', 'messages', 'phone', 'photos',
    'telegram', 'snapchat', 'tiktok', 'amazon', 'uber',
    'play store', 'files', 'browser', 'music', 'notes',
  ];
}
