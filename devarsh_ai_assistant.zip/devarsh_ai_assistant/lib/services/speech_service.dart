// services/speech_service.dart — wraps speech_to_text
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_recognition_error.dart';

enum SpeechState { idle, listening, processing, error }

typedef OnResult         = void Function(String finalText);
typedef OnPartialResult  = void Function(String partialText);
typedef OnError          = void Function(String error);
typedef OnStateChange    = void Function(SpeechState state);

class SpeechService {
  final SpeechToText _stt = SpeechToText();
  bool _initialized = false;
  SpeechState _state = SpeechState.idle;

  SpeechState get state => _state;
  bool get isListening => _state == SpeechState.listening;

  Future<bool> initialize() async {
    if (_initialized) return true;
    _initialized = await _stt.initialize(
      onError: (SpeechRecognitionError e) =>
          // ignore: avoid_print
          print('[Speech] error: \${e.errorMsg}'),
      debugLogging: false,
    );
    return _initialized;
  }

  Future<void> startListening({
    required OnResult onResult,
    required OnPartialResult onPartialResult,
    required OnError onError,
    required OnStateChange onStateChange,
    String localeId = 'en_US',
  }) async {
    if (!_initialized) {
      final ok = await initialize();
      if (!ok) { onError('Speech recognition unavailable.'); return; }
    }
    if (_stt.isListening) await stopListening();
    _setState(SpeechState.listening, onStateChange);

    await _stt.listen(
      onResult: (SpeechRecognitionResult r) {
        onPartialResult(r.recognizedWords);
        if (r.finalResult) {
          _setState(SpeechState.idle, onStateChange);
          onResult(r.recognizedWords);
        }
      },
      localeId: localeId,
      listenMode: ListenMode.confirmation,
      pauseFor: const Duration(seconds: 3),
      listenFor: const Duration(seconds: 30),
      partialResults: true,
      cancelOnError: false,
    );

    _stt.statusListener = (status) {
      if ((status == 'done' || status == 'notListening') &&
          _state == SpeechState.listening) {
        _setState(SpeechState.idle, onStateChange);
      }
    };
  }

  Future<void> stopListening() async { await _stt.stop(); _state = SpeechState.idle; }
  Future<void> cancelListening() async { await _stt.cancel(); _state = SpeechState.idle; }
  void _setState(SpeechState s, OnStateChange cb) { _state = s; cb(s); }
  void dispose() => _stt.cancel();
}
