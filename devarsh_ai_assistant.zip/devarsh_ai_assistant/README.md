# Devarsh AI Assistant 🤖

A JARVIS-style AI voice assistant Android app built with Flutter.

---

## Features
- 🎤 Voice commands via microphone (speech-to-text)
- 🔊 AI responses spoken aloud (text-to-speech)
- 🤖 Google Gemini or OpenAI GPT integration
- 📱 Open any installed app by voice ("Open YouTube")
- 🔦 Flashlight ON/OFF
- ⏰ Set alarms, open dialer, SMS
- 🔔 Persistent foreground service notification
- 🌙 Material 3 dark theme

---

## Build Instructions

### Option 1: Build on PC/Laptop (Recommended)

**Prerequisites:**
- Flutter SDK 3.x installed
- Android Studio + Android SDK
- Java 17+

```bash
# 1. Extract ZIP and go to project folder
cd devarsh_ai_assistant

# 2. Install dependencies
flutter pub get

# 3. Build APK
flutter build apk --release

# APK will be at:
# build/app/outputs/flutter-apk/app-release.apk

# 4. Install on connected phone
flutter install
```

---

### Option 2: AndroidIDE (Build on Phone)

1. Install **AndroidIDE** from GitHub: https://github.com/AndroidIDEOfficial/AndroidIDE/releases
2. Install **JDK 17** inside AndroidIDE terminal:
   ```bash
   ideapt install jdk
   ```
3. Install Flutter SDK:
   ```bash
   git clone https://github.com/flutter/flutter.git ~/flutter --depth 1 -b stable
   export PATH="$PATH:$HOME/flutter/bin"
   flutter doctor
   ```
4. Extract project ZIP to `/sdcard/` or home directory
5. Open terminal in AndroidIDE:
   ```bash
   cd devarsh_ai_assistant
   flutter pub get
   flutter build apk
   ```
6. Find APK in `build/app/outputs/flutter-apk/`

---

### Option 3: GitHub Actions (Cloud Build — No PC Needed)

1. Push this project to a GitHub repo
2. Create `.github/workflows/build.yml`:
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.19.0'
      - run: flutter pub get
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v3
        with:
          name: app-release.apk
          path: build/app/outputs/flutter-apk/app-release.apk
```
3. After push, go to Actions tab → download the APK artifact

---

## Setup After Install

1. Open the app → tap **Get Started**
2. Grant **Microphone** and **Notification** permissions
3. Disable battery optimisation when prompted
4. Go to **Settings** → add your API key:
   - **Gemini (Free):** https://aistudio.google.com/app/apikey
   - **OpenAI:** https://platform.openai.com/api-keys
5. Tap the mic button and speak!

---

## Voice Commands Examples

| Say this... | Does this |
|---|---|
| "Open YouTube" | Opens YouTube |
| "Open WhatsApp" | Opens WhatsApp |
| "Turn on flashlight" | Turns on torch |
| "Turn off flashlight" | Turns off torch |
| "Call 9876543210" | Opens dialer with number |
| "Set alarm for 7 AM" | Opens Clock with alarm pre-set |
| "Open camera" | Opens Camera app |
| "Open Settings" | Opens device Settings |
| "What is the capital of India?" | Asks AI, speaks response |
| "Tell me a joke" | Asks AI, speaks response |

---

## Project Structure

```
lib/
├── main.dart                     # App entry point
├── models/
│   ├── chat_message.dart         # Message data model
│   └── app_settings.dart         # Settings data model
├── services/
│   ├── assistant_provider.dart   # Main state (Riverpod)
│   ├── speech_service.dart       # Microphone / STT
│   ├── tts_service.dart          # Text-to-speech
│   ├── ai_service.dart           # Gemini / OpenAI API
│   ├── intent_service.dart       # Android intents (app launch etc.)
│   ├── flashlight_service.dart   # Torch control
│   ├── foreground_service.dart   # Background service
│   ├── permission_service.dart   # Runtime permissions
│   └── storage_service.dart      # SharedPreferences
├── screens/
│   ├── home_screen.dart          # Main chat UI
│   ├── settings_screen.dart      # Settings page
│   └── onboarding_screen.dart    # First-run setup
├── widgets/
│   ├── mic_button.dart           # Animated mic button
│   ├── chat_bubble.dart          # Message bubble
│   ├── status_bar.dart           # Listening/thinking status
│   └── app_logo.dart             # App logo widget
└── utils/
    ├── constants.dart            # App-wide constants
    ├── command_parser.dart       # Voice command parser
    └── theme.dart                # Material 3 dark theme
```

---

## Android Restrictions (Important)

- ❌ Cannot auto-call without user confirmation (dialer opens instead)
- ❌ Cannot restart after Force Stop (user must reopen app)
- ❌ Cannot programmatically disable battery optimisation (user must do it)
- ❌ Cannot control volume/brightness without WRITE_SETTINGS (not requested)
- ✅ All features respect Android security and privacy rules

---

## Package Info

- **Package ID:** `com.devarsh.ai_assistant`
- **Min Android:** 6.0 (API 23)
- **Target Android:** Latest stable
- **Flutter:** 3.x (Dart 3.x)
