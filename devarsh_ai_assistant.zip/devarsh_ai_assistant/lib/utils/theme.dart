// utils/theme.dart — Material 3 dark theme (deep-space indigo + cyan)
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  AppTheme._();

  static const Color primaryColor  = Color(0xFF5B5FEF);
  static const Color accentColor   = Color(0xFF00E5FF);
  static const Color cardColor     = Color(0xFF1A1A2E);
  static const Color bgColor       = Color(0xFF0F0F1A);

  static ThemeData get dark {
    final cs = ColorScheme.fromSeed(
      seedColor: primaryColor,
      brightness: Brightness.dark,
      surface: bgColor,
      primary: primaryColor,
      secondary: accentColor,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: cs,
      scaffoldBackgroundColor: bgColor,
      textTheme: GoogleFonts.soraTextTheme(ThemeData.dark().textTheme).copyWith(
        displayLarge: GoogleFonts.sora(fontSize: 32, fontWeight: FontWeight.w700, color: Colors.white),
        titleLarge:   GoogleFonts.sora(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white),
        bodyLarge:    GoogleFonts.inter(fontSize: 16, color: Colors.white70),
        bodyMedium:   GoogleFonts.inter(fontSize: 14, color: Colors.white60),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bgColor, elevation: 0, centerTitle: true,
        titleTextStyle: GoogleFonts.sora(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
      cardTheme: CardTheme(
        color: cardColor, elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: cardColor,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.1))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.1))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: primaryColor, width: 1.5)),
        labelStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
        hintStyle:  TextStyle(color: Colors.white.withOpacity(0.3)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor, foregroundColor: Colors.white, elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: GoogleFonts.inter(fontSize: 15, fontWeight: FontWeight.w600)),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? accentColor : Colors.white38),
        trackColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? accentColor.withOpacity(0.35) : Colors.white12),
      ),
      dividerTheme: DividerThemeData(color: Colors.white.withOpacity(0.08), thickness: 1),
    );
  }
}
