// services/intent_service.dart
// Launches Android intents: apps, dialer, SMS, alarms, camera, settings.
// Uses android_intent_plus and device_apps packages.
import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:device_apps/device_apps.dart';
import 'package:url_launcher/url_launcher.dart';

class IntentService {
  IntentService._();

  // ── Open app by name ─────────────────────────────────────────────────────
  // First tries to find a matching installed app via DeviceApps,
  // then falls back to a package-name lookup for common apps.
  static Future<bool> openAppByName(String appName) async {
    final lower = appName.toLowerCase().trim();

    // 1. Well-known package name map
    final packageMap = _packageMap();
    if (packageMap.containsKey(lower)) {
      return _launchPackage(packageMap[lower]!);
    }

    // 2. Search installed apps by display name (case-insensitive substring)
    try {
      final apps = await DeviceApps.getInstalledApplications(
          includeAppIcons: false, includeSystemApps: true);
      final match = apps.where((a) =>
          a.appName.toLowerCase().contains(lower)).toList();
      if (match.isNotEmpty) {
        return DeviceApps.openApp(match.first.packageName);
      }
    } catch (_) {}

    // 3. Fallback: Play Store search
    final uri = Uri.parse('market://search?q=\$appName');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
      return true;
    }
    return false;
  }

  // ── Open Camera ──────────────────────────────────────────────────────────
  static Future<void> openCamera() async {
    const intent = AndroidIntent(
      action: 'android.media.action.IMAGE_CAPTURE',
      flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
    );
    await intent.launch();
  }

  // ── Open Settings ────────────────────────────────────────────────────────
  static Future<void> openSettings() async {
    const intent = AndroidIntent(
      action: 'android.settings.SETTINGS',
      flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
    );
    await intent.launch();
  }

  // ── Open Dialer (pre-fills number but does NOT auto-call) ────────────────
  // Android security: apps cannot auto-initiate a call without CALL_PHONE
  // permission AND explicit user confirmation. We open the dialer instead.
  static Future<void> openDialer(String phoneNumber) async {
    final uri = Uri.parse('tel:\$phoneNumber');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  // ── Open SMS app ─────────────────────────────────────────────────────────
  static Future<void> openSms({String? phoneNumber, String? body}) async {
    final uri = Uri.parse(
        'sms:\${phoneNumber ?? ""}?\${body != null ? "body=\$body" : ""}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  // ── Set Alarm ────────────────────────────────────────────────────────────
  // Uses the standard Android alarm clock intent; opens the Clock app
  // with hour/minute pre-filled. The user confirms in the Clock UI.
  static Future<void> setAlarm({
    required int hour,
    required int minute,
    String message = 'Devarsh AI Alarm',
  }) async {
    final intent = AndroidIntent(
      action: 'android.intent.action.SET_ALARM',
      flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      arguments: {
        'android.intent.extra.alarm.HOUR': hour,
        'android.intent.extra.alarm.MINUTES': minute,
        'android.intent.extra.alarm.MESSAGE': message,
        'android.intent.extra.alarm.SKIP_UI': false, // show UI for confirmation
      },
    );
    await intent.launch();
  }

  // ── Helpers ──────────────────────────────────────────────────────────────
  static Future<bool> _launchPackage(String packageName) async {
    try {
      return await DeviceApps.openApp(packageName);
    } catch (_) {
      return false;
    }
  }

  static Map<String, String> _packageMap() => {
        'youtube':      'com.google.android.youtube',
        'whatsapp':     'com.whatsapp',
        'chrome':       'com.android.chrome',
        'gmail':        'com.google.android.gm',
        'maps':         'com.google.android.apps.maps',
        'google maps':  'com.google.android.apps.maps',
        'instagram':    'com.instagram.android',
        'facebook':     'com.facebook.katana',
        'twitter':      'com.twitter.android',
        'x':            'com.twitter.android',
        'spotify':      'com.spotify.music',
        'netflix':      'com.netflix.mediaclient',
        'calculator':   'com.google.android.calculator',
        'calendar':     'com.google.android.calendar',
        'clock':        'com.google.android.deskclock',
        'contacts':     'com.google.android.contacts',
        'messages':     'com.google.android.apps.messaging',
        'phone':        'com.google.android.dialer',
        'photos':       'com.google.android.apps.photos',
        'telegram':     'org.telegram.messenger',
        'snapchat':     'com.snapchat.android',
        'tiktok':       'com.zhiliaoapp.musically',
        'amazon':       'com.amazon.mShop.android.shopping',
        'uber':         'com.ubercab',
        'play store':   'com.android.vending',
        'files':        'com.google.android.apps.nbu.files',
        'music':        'com.google.android.music',
        'notes':        'com.google.android.keep',
        'keep':         'com.google.android.keep',
      };
}
