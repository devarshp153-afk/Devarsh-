// models/app_settings.dart
class AppSettings {
  final String apiKey;
  final AiProvider aiProvider;
  final double ttsSpeed;
  final String ttsLanguage;
  final bool autoStartOnBoot;

  const AppSettings({
    this.apiKey = '',
    this.aiProvider = AiProvider.gemini,
    this.ttsSpeed = 0.5,
    this.ttsLanguage = 'en-US',
    this.autoStartOnBoot = false,
  });

  AppSettings copyWith({
    String? apiKey, AiProvider? aiProvider,
    double? ttsSpeed, String? ttsLanguage, bool? autoStartOnBoot,
  }) => AppSettings(
        apiKey: apiKey ?? this.apiKey,
        aiProvider: aiProvider ?? this.aiProvider,
        ttsSpeed: ttsSpeed ?? this.ttsSpeed,
        ttsLanguage: ttsLanguage ?? this.ttsLanguage,
        autoStartOnBoot: autoStartOnBoot ?? this.autoStartOnBoot);

  Map<String, dynamic> toJson() => {
        'apiKey': apiKey, 'aiProvider': aiProvider.name,
        'ttsSpeed': ttsSpeed, 'ttsLanguage': ttsLanguage,
        'autoStartOnBoot': autoStartOnBoot};

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        apiKey: json['apiKey'] as String? ?? '',
        aiProvider: AiProvider.values.byName(
            json['aiProvider'] as String? ?? 'gemini'),
        ttsSpeed: (json['ttsSpeed'] as num?)?.toDouble() ?? 0.5,
        ttsLanguage: json['ttsLanguage'] as String? ?? 'en-US',
        autoStartOnBoot: json['autoStartOnBoot'] as bool? ?? false);
}

enum AiProvider { gemini, openai }
