// services/tts_service.dart — wraps flutter_tts
import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool _isSpeaking = false;
  bool get isSpeaking => _isSpeaking;

  Future<void> initialize({
    double speed = 0.5, double pitch = 1.0,
    double volume = 1.0, String language = 'en-US',
  }) async {
    await _tts.setLanguage(language);
    await _tts.setSpeechRate(speed);
    await _tts.setPitch(pitch);
    await _tts.setVolume(volume);
    await _tts.awaitSpeakCompletion(true);
    _tts.setStartHandler(()     => _isSpeaking = true);
    _tts.setCompletionHandler(() => _isSpeaking = false);
    _tts.setCancelHandler(()   => _isSpeaking = false);
    _tts.setErrorHandler((_)   => _isSpeaking = false);
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    if (_isSpeaking) await stop();
    await _tts.speak(_clean(text));
  }

  Future<void> stop() async { await _tts.stop(); _isSpeaking = false; }
  Future<void> setSpeed(double s) => _tts.setSpeechRate(s);
  Future<void> setLanguage(String l) => _tts.setLanguage(l);

  Future<List<String>> getAvailableLanguages() async {
    final langs = await _tts.getLanguages;
    return (langs as List).cast<String>()..sort();
  }

  void dispose() => _tts.stop();

  String _clean(String t) => t
      .replaceAll(RegExp(r'\*{1,2}'), '')
      .replaceAll(RegExp(r'#{1,6}\s'), '')
      .replaceAll(RegExp(r'`{1,3}'), '')
      .replaceAll(RegExp(r'\n{2,}'), '. ')
      .replaceAll('\n', ' ')
      .trim();
}
