// lib/main.dart — App entry point
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'services/storage_service.dart';
import 'services/foreground_service.dart';
import 'utils/theme.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait mode
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp, DeviceOrientation.portraitDown,
  ]);

  // Set system UI style (dark status bar)
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  // Initialize local storage
  await StorageService.init();

  // Initialize foreground service options (does NOT start the service yet)
  ForegroundServiceManager.initOptions();

  runApp(
    // ProviderScope is required at the root for Riverpod to work
    const ProviderScope(child: DevarshAiApp()),
  );
}

class DevarshAiApp extends StatelessWidget {
  const DevarshAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final showOnboarding = !StorageService.onboardingDone;
    return MaterialApp(
      title: 'Devarsh AI Assistant',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: showOnboarding ? const OnboardingScreen() : const HomeScreen(),
    );
  }
}
